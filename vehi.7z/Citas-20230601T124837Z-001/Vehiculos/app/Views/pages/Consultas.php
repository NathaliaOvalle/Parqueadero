<!DOCTYPE html>
<html>
<head>
    <title>Consultas</title>
</head>
<body>
    <h2>Consulta Vehiculos</h2>

    <form method="GET" action="consultar_placa.php">
        <label>PLaca:</label>
        <input type="name" name="placa" required>
        <input type="submit" value="Consultar">
    </form>

    <h3>Consultas:</h3>
    <table>
        <thead>
            <tr>
                <th>PLACA</th>
                <th>TIPO</th>
                <th>TARIFA</th>
                <th>CONDUCTOR</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</body>
</html>
