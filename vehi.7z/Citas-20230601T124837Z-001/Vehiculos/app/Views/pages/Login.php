<!DOCTYPE html>
<html>
<head>
    <title>Parqueadero Villa del Rio</title>
</head>
<body>
    <h2>Ingresar</h2>
    <form method="POST" action="validar_login.php">
        <label>PLaca:</label>
        <input type="text" name="placa" required><br>

        <label>TipoVehiculo:</label>
        <input type="password" name="tipo" required><br>

        <label>Tarifa:</label>
        <input type="numer" name="tarifa" required><br>

        <label>IngresoConductor:</label>
        <input type="text" name="conductor" required><br>

        <label>Tiempo:</label>
        <input type="text" name="tiempo" required><br>
        
        <input type="submit" value="Validar">
    </form>
</body>
</html>
