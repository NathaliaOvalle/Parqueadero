<?php
namespace App\Models;

use CodeIgniter\Model;

class N_vehiculos extends Model{

    protected $primaryKey = 'id';

    protected $alloWedFields = ['placa', 'tipo', 'tiempo', 'conductor','tarifa'];
}