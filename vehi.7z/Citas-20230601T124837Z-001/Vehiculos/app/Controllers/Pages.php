<?php
namespace App/Controllers

use CodeIgniter/Controller;
use App/Models/Pages.php;

class Pages.php extends Controller{

public function index()
    {
        return view('welcome_message');
    }
}