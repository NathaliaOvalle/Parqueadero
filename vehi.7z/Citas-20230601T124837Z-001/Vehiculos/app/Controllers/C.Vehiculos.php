<?php
namespace App\Models;

use CodeIgniter\Controller;
use App\Models\N_vehiculos;

class C_Vehiculos extends Controller{

    public function index()
    {
        $vehiculos = new N_vehiculos();
        $datos['vehiculos']=$vehiculos->findAll();
        return view('welcome_message', $datos);
    }
}
   
